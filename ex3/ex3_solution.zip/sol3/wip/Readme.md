# WIP: Optional Student Task 19
After successfully completing the third exercise in VLSI 1, you have just received a job offer from Tomorrowland Inc. During the upcoming festival, you would be in charge of the visual effects. As you were announced in the last minute, you will start from the current screen splitter.
1. Open filt_fsm.sv file in location 3_counter/sourcecode using a text editor.
You want to create a dynamic mixture based on the available filters. In order to synchronise with the music that will be played, the organizers told you that your visuals have to change every 100ms (i.e. a different combination of filters has to be displayed every 100ms). As you already discovered, the signal that flags the end of each frame of pixels is vsync. Therefore, we can use this to synchronise our visuals.
2. Take a look at the simulation. What is the frequency of vsync_i? After how many pulses of vsync_i (i.e. frames) do we have to change the filters?
3. Use vsync_i to count the frames and, every time you reach the limit, use mode_selector_q to iterate through the available filters.
4. Click on ’Generate Bitstream’ on the left side pane in Vivado window and initiate bit stream generation process.
5. Once the bitstream is ready, open ’Hardware Manager’ and program the FPGA using the bitstream just created.

Author: Cioflan Cristian <cioflanc@student.ethz.ch>
